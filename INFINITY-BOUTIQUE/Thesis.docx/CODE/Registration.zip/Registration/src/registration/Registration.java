package registration;
public class Registration {
    public static void main(String[] args) {
        Register r1=new Register();
        r1.setVisible(true);
    }
}