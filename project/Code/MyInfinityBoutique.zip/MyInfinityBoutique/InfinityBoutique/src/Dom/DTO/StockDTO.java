/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dom.DTO;

/**
 *
 * @author Jadoon
 */
public class StockDTO {
    public String ItemID;
    public String Quantity;
    public String Price;
}
