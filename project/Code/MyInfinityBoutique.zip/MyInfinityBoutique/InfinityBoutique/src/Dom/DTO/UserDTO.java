/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dom.DTO;

/**
 *
 * @author Attou
 */
public class UserDTO {
    public String FirstName;
    public String LastName;
    public String Username;
    public String Email;
    public String PhoneNo;
    public String Password;
    public String ItemID;
    public String Quantity;
    public String Price;
}
