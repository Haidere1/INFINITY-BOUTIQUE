/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAL;

import Dom.DTO.Message;
import Dom.DTO.MessageType;
import Dom.DTO.Response;
import Dom.DTO.StockDTO;
import Dom.DTO.UserDTO;
import Dom.SMSFactory;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;

/**
 *
 * @author Attou
 */
public class DALManager {
    DBAdder objAdder;
    DBReader objReader;
    SqlConnection objConnection;
    RecordMapper objMapper;

    public DALManager(RecordMapper mapper) {
        objConnection = new SqlConnection("localhost:3306","managestock", "root","omiya20");
        objAdder = SMSFactory.getInstanceOfAdder();
        objReader = SMSFactory.getInstanceOfReader();
        this.objMapper=mapper;
    }
    
    public ArrayList<UserDTO> getEmployeesList(String searchKey) {
                
        Connection  dbConnection = objConnection.getConnection();
        String viewEmployeesQuery = "Select * from Users where Username='"+searchKey+"';";
        
        ResultSet rs = objReader.getRecords(viewEmployeesQuery, dbConnection);
        return objMapper.getUsers(rs);        
    }  
    
    public void saveUser(UserDTO objUser, Response objResponse) {
        try{
            Connection  dbConnection = objConnection.getConnection();
            objAdder.saveEmployee(objUser,objResponse,dbConnection);            
        }catch(Exception e){
        objResponse.messagesList.add(new Message("Ooops! Failed to create user, Please contact support that there an issue while saving new employee.", MessageType.Error));
        objResponse.messagesList.add(new Message(e.getMessage() + "\n Stack Track:\n"+e.getStackTrace(), MessageType.Exception));
        }
    }
    public void saveStock(StockDTO objUser, Response objResponse) {
        try{
            Connection  dbConnection = objConnection.getConnection();
            objAdder.saveStock(objUser,objResponse,dbConnection);            
        }catch(Exception e){
        objResponse.messagesList.add(new Message("Ooops! Failed to create user, Please contact support that there an issue while saving new employee.", MessageType.Error));
        objResponse.messagesList.add(new Message(e.getMessage() + "\n Stack Track:\n"+e.getStackTrace(), MessageType.Exception));
        }
    }
    
}
